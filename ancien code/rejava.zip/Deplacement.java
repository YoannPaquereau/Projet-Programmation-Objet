import javax.swing.*;
import javax.swing.border.*;
import java.awt.*;
import java.awt.event.*;

public interface Deplacement{

	public void paintComponent(Graphics g);
	public void actionPerformed(ActionEvent e);

}
