Projet réalisé par PAQUEREAU Yoann et TRAORE Abdoul Aziz

Pour lancer le jeu, compiler le fichier "Jouer.java" en faisant :
javac Jouer.java
java Jouer
